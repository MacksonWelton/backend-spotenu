"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.userRouter = void 0;
var express_1 = __importDefault(require("express"));
var UserController_1 = require("../controller/UserController");
//linha responsável por criar um módulo de rotas no express
exports.userRouter = express_1.default.Router();
exports.userRouter.post("/listener-signup", new UserController_1.UserController().listenerSignup);
exports.userRouter.post("/premium-listener-signup", new UserController_1.UserController().PremiumListenerSignup);
exports.userRouter.post("/admin-signup", new UserController_1.UserController().adminSignup);
exports.userRouter.post("/band-singup", new UserController_1.UserController().bandSignup);
exports.userRouter.get("/all-bands", new UserController_1.UserController().getAllBands);
exports.userRouter.put("/approve-band", new UserController_1.UserController().approveBand);
exports.userRouter.post("/login", new UserController_1.UserController().login);
exports.userRouter.get("/all-listener", new UserController_1.UserController().getAllListeners);
exports.userRouter.put("/promote-listener", new UserController_1.UserController().promoteListener);
exports.userRouter.put("/approve-listener", new UserController_1.UserController().approveListener);
exports.userRouter.get("/id-user", new UserController_1.UserController().getIdUser);
exports.userRouter.put("/edit-user-name", new UserController_1.UserController().editUserName);
