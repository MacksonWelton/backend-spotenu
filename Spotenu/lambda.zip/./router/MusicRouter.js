"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.musicRouter = void 0;
var express_1 = __importDefault(require("express"));
var MusicController_1 = require("../controller/MusicController");
exports.musicRouter = express_1.default.Router();
exports.musicRouter.post("/add-music", new MusicController_1.MusicController().addMusic);
exports.musicRouter.get("/all-musics", new MusicController_1.MusicController().getAllMusics);
exports.musicRouter.get("/musics-by-band", new MusicController_1.MusicController().getMusicsByBand);
exports.musicRouter.get("/search", new MusicController_1.MusicController().searchMusics);
exports.musicRouter.put("/edit-music-name", new MusicController_1.MusicController().editMusicName);
exports.musicRouter.delete("/delete-music/:musicId", new MusicController_1.MusicController().deleteMusic);
