"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.playlistRouter = void 0;
var express_1 = __importDefault(require("express"));
var PlaylistController_1 = require("../controller/PlaylistController");
exports.playlistRouter = express_1.default.Router();
exports.playlistRouter.post("/create-playlist", new PlaylistController_1.PlaylistController().createPlaylist);
exports.playlistRouter.post("/add-music-to-playlist", new PlaylistController_1.PlaylistController().addMusicToPlaylist);
exports.playlistRouter.get("/playlists-by-user", new PlaylistController_1.PlaylistController().getPlaylistsByUser);
exports.playlistRouter.get("/all-playlists", new PlaylistController_1.PlaylistController().getAllPlaylists);
exports.playlistRouter.get("/musics-by-playlist", new PlaylistController_1.PlaylistController().getMusicsByPlaylist);
exports.playlistRouter.put("/edit-playlist-name", new PlaylistController_1.PlaylistController().editPlaylistName);
exports.playlistRouter.post("/make-playlist-collaborative", new PlaylistController_1.PlaylistController().makePlaylistCollaborative);
exports.playlistRouter.get("/collaborative-playlists", new PlaylistController_1.PlaylistController().getCollaborativePlaylists);
exports.playlistRouter.post("/follow-collaborative-playlist", new PlaylistController_1.PlaylistController().followCollaborativePlaylist);
exports.playlistRouter.delete("/delete-musics-from-playlist/:playlistId/:musicsId", new PlaylistController_1.PlaylistController().deleteMusicFromPlaylist);
