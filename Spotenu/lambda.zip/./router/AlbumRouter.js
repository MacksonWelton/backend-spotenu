"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.albumRouter = void 0;
var express_1 = __importDefault(require("express"));
var AlbumController_1 = require("../controller/AlbumController");
exports.albumRouter = express_1.default.Router();
exports.albumRouter.post("/create-album", new AlbumController_1.AlbumController().createAlbum);
exports.albumRouter.get("/musics-by-album", new AlbumController_1.AlbumController().getMusicsbyAlbum);
exports.albumRouter.get("/albums", new AlbumController_1.AlbumController().getAllAlbums);
exports.albumRouter.get("/albums-by-band", new AlbumController_1.AlbumController().getAlbumByBand);
exports.albumRouter.put("/edit-album-name", new AlbumController_1.AlbumController().editAlbumName);
exports.albumRouter.put("/edit-album-genres", new AlbumController_1.AlbumController().editAlbumGenres);
exports.albumRouter.delete("/delete-album/:id", new AlbumController_1.AlbumController().deleteAlbum);
