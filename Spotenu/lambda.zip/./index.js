"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var express_1 = __importDefault(require("express"));
var dotenv_1 = __importDefault(require("dotenv"));
var UserRouter_1 = require("./router/UserRouter");
var MusicRouter_1 = require("./router/MusicRouter");
var PlaylistRouter_1 = require("./router/PlaylistRouter");
var cors_1 = __importDefault(require("cors"));
var AlbumRouter_1 = require("./router/AlbumRouter");
var GenreRouter_1 = require("./router/GenreRouter");
dotenv_1.default.config();
var app = express_1.default();
app.use(cors_1.default());
app.use(express_1.default.json());
app.use("/users/", UserRouter_1.userRouter);
app.use("/musics/", MusicRouter_1.musicRouter);
app.use("/playlists/", PlaylistRouter_1.playlistRouter);
app.use("/albums/", AlbumRouter_1.albumRouter);
app.use("/genres/", GenreRouter_1.genreRouter);
exports.default = app;
var server = app.listen(3001, function () {
    if (server) {
        var address = server.address();
        console.log("Servidor rodando em http://localhost:" + address.port);
    }
    else {
        console.error("Falha ao rodar o servidor.");
    }
});
