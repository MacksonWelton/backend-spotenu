"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.stringToUserRole = exports.UserRole = exports.User = void 0;
var InvalidParameterError_1 = require("../Erros/InvalidParameterError");
var User = /** @class */ (function () {
    function User(id, name, nickname, email, password, isApproved, role) {
        this.id = id;
        this.name = name;
        this.nickname = nickname;
        this.email = email;
        this.password = password;
        this.isApproved = isApproved;
        this.role = role;
    }
    User.prototype.getId = function () {
        return this.id;
    };
    User.prototype.getName = function () {
        return this.name;
    };
    User.prototype.getNickname = function () {
        return this.nickname;
    };
    User.prototype.getEmail = function () {
        return this.email;
    };
    User.prototype.getPassword = function () {
        return this.password;
    };
    User.prototype.getIsApproved = function () {
        return this.isApproved;
    };
    User.prototype.getRole = function () {
        return this.role;
    };
    return User;
}());
exports.User = User;
var UserRole;
(function (UserRole) {
    UserRole["BAND"] = "BAND";
    UserRole["PREMIUM_LISTENER"] = "PREMIUM LISTENER";
    UserRole["FREE_LISTENER"] = "FREE LISTENER";
    UserRole["ADM"] = "ADMINISTRATOR";
})(UserRole = exports.UserRole || (exports.UserRole = {}));
exports.stringToUserRole = function (input) {
    switch (input) {
        case "BAND":
            return UserRole.BAND;
        case "PREMIUM LISTENER":
            return UserRole.PREMIUM_LISTENER;
        case "FREE LISTENER":
            return UserRole.FREE_LISTENER;
        case "ADMINISTRATOR":
            return UserRole.ADM;
        default:
            throw new InvalidParameterError_1.InvalidParameterError("Invalid user role");
    }
};
