"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var express_1 = __importDefault(require("express"));
var UserRouter_1 = require("./router/UserRouter");
var MusicRouter_1 = require("./router/MusicRouter");
var app = express_1.default();
app.use(express_1.default.json());
app.use("/users/", UserRouter_1.userRouter);
app.use("/musics/", MusicRouter_1.musicRouter);
var server = app.listen(3000, function () {
    if (server) {
        var address = server.address();
        console.log("Servidor rodando em http://localhost:" + address.port);
    }
    else {
        console.error("Falha ao rodar o servidor.");
    }
});
