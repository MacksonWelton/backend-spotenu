"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlaylistDatabase = void 0;
var BaseDatabase_1 = require("./BaseDatabase");
var PlaylistDatabase = /** @class */ (function (_super) {
    __extends(PlaylistDatabase, _super);
    function PlaylistDatabase() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    PlaylistDatabase.prototype.createPlaylist = function (id, userId, name) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, _super.prototype.getConnection.call(this).raw("\n      INSERT INTO " + PlaylistDatabase.TABLE_PLAYLIST + " (playlist_id, playlist_name, id_user)\n      VALUES(\"" + id + "\", \"" + name + "\", \"" + userId + "\")\n    ")];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    PlaylistDatabase.prototype.addMusicToPlaylist = function (playlistId, musicsId) {
        return __awaiter(this, void 0, void 0, function () {
            var playlist;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        playlist = musicsId.map(function (id) { return ({
                            playlist_id: playlistId,
                            music_id: id
                        }); });
                        return [4 /*yield*/, _super.prototype.getConnection.call(this)
                                .insert(playlist)
                                .into(PlaylistDatabase.TABLE_PLAYLIST_MUSIC)];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    PlaylistDatabase.prototype.getPlaylistsByUser = function (userId, playlistsPerPage, offset) {
        return __awaiter(this, void 0, void 0, function () {
            var collaborativePlaylist, idCollaborativePlaylist, result, numberOfRows;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, _super.prototype.getConnection.call(this).raw("\n      SELECT playlist_id FROM " + PlaylistDatabase.TABLE_COLLABORATIVE_PLAYLISTS + "\n      WHERE followers_id = \"" + userId + "\" OR playlist_owner_id = \"" + userId + "\"\n    ")];
                    case 1:
                        collaborativePlaylist = _a.sent();
                        idCollaborativePlaylist = collaborativePlaylist[0].map(function (playlist) {
                            return ("'" + playlist.playlist_id + "'");
                        }).toString();
                        return [4 /*yield*/, _super.prototype.getConnection.call(this).raw("\n      SELECT SQL_CALC_FOUND_ROWS * FROM " + PlaylistDatabase.TABLE_PLAYLIST + "\n      WHERE playlist_id IN (" + idCollaborativePlaylist + ")\n      OR id_user = \"" + userId + "\"\n      LIMIT " + playlistsPerPage + " OFFSET " + offset + "\n    ")];
                    case 2:
                        result = _a.sent();
                        return [4 /*yield*/, _super.prototype.getConnection.call(this).raw("\n      SELECT FOUND_ROWS() as numberOfRows;\n    ")];
                    case 3:
                        numberOfRows = _a.sent();
                        return [2 /*return*/, { numberOfRows: numberOfRows[0][0].numberOfRows, playlists: result[0] }];
                }
            });
        });
    };
    PlaylistDatabase.prototype.getAllPlaylists = function (playlistsPerPage, offset) {
        return __awaiter(this, void 0, void 0, function () {
            var result, numberOfRows;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, _super.prototype.getConnection.call(this).raw("\n      SELECT SQL_CALC_FOUND_ROWS * FROM " + PlaylistDatabase.TABLE_PLAYLIST + "\n      LIMIT " + playlistsPerPage + " OFFSET " + offset + "\n    ")];
                    case 1:
                        result = _a.sent();
                        return [4 /*yield*/, _super.prototype.getConnection.call(this).raw("\n      SELECT FOUND_ROWS() as numberOfRows;\n    ")];
                    case 2:
                        numberOfRows = _a.sent();
                        return [2 /*return*/, { numberOfRows: numberOfRows[0][0].numberOfRows, playlists: result[0] }];
                }
            });
        });
    };
    PlaylistDatabase.prototype.getMusicsByPlaylist = function (playlistId, musicsByPlaylistPerPage, offset) {
        return __awaiter(this, void 0, void 0, function () {
            var result, numberOfRows;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, _super.prototype.getConnection.call(this).raw("\n      SELECT SQL_CALC_FOUND_ROWS * FROM " + PlaylistDatabase.TABLE_PLAYLIST_MUSIC + "\n      JOIN " + PlaylistDatabase.TABLE_MUSIC + "\n      ON spotenu_musics.music_id = spotenu_playlists_musics.music_id\n      and playlist_id = \"" + playlistId + "\"\n      LIMIT " + musicsByPlaylistPerPage + " OFFSET " + offset + "\n    ")];
                    case 1:
                        result = _a.sent();
                        return [4 /*yield*/, _super.prototype.getConnection.call(this).raw("\n      SELECT FOUND_ROWS() as numberOfRows;\n   ")];
                    case 2:
                        numberOfRows = _a.sent();
                        return [2 /*return*/, { numberOfRows: numberOfRows[0][0].numberOfRows, musics: result[0] }];
                }
            });
        });
    };
    PlaylistDatabase.prototype.editPlaylistName = function (playlistId, playlistName) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, _super.prototype.getConnection.call(this).raw("\n      UPDATE " + PlaylistDatabase.TABLE_PLAYLIST + "\n      SET playlist_name = \"" + playlistName + "\"\n      WHERE playlist_id = \"" + playlistId + "\"\n    ")];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    PlaylistDatabase.prototype.makePlaylistCollaborative = function (playlistId, idOwner, isPrivate) {
        return __awaiter(this, void 0, void 0, function () {
            var isPrivateNumber;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        isPrivateNumber = _super.prototype.convertBooleanToTinyInt.call(this, isPrivate);
                        if (!isPrivate) return [3 /*break*/, 2];
                        return [4 /*yield*/, _super.prototype.getConnection.call(this).raw("\n        DELETE FROM " + PlaylistDatabase.TABLE_COLLABORATIVE_PLAYLISTS + "\n        WHERE playlist_id = \"" + playlistId + "\"\n    ")];
                    case 1:
                        _a.sent();
                        return [3 /*break*/, 4];
                    case 2: return [4 /*yield*/, _super.prototype.getConnection.call(this).raw("\n        INSERT INTO " + PlaylistDatabase.TABLE_COLLABORATIVE_PLAYLISTS + " (playlist_id, playlist_owner_id)\n        VALUES(\"" + playlistId + "\", \"" + idOwner + "\")\n    ")];
                    case 3:
                        _a.sent();
                        _a.label = 4;
                    case 4: return [4 /*yield*/, _super.prototype.getConnection.call(this).raw("\n    UPDATE " + PlaylistDatabase.TABLE_PLAYLIST + "\n    SET is_private = \"" + isPrivateNumber + "\"\n    WHERE playlist_id = \"" + playlistId + "\"\n  ")];
                    case 5:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    PlaylistDatabase.prototype.getCollaborativePlaylists = function (collaborativePlaylistPerPage, offset) {
        return __awaiter(this, void 0, void 0, function () {
            var result, numberOfRows;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, _super.prototype.getConnection.call(this).raw("\n      SELECT SQL_CALC_FOUND_ROWS * FROM " + PlaylistDatabase.TABLE_PLAYLIST + "\n      WHERE is_private = 0\n      LIMIT " + collaborativePlaylistPerPage + " OFFSET " + offset + "\n    ")];
                    case 1:
                        result = _a.sent();
                        return [4 /*yield*/, _super.prototype.getConnection.call(this).raw("\n      SELECT FOUND_ROWS() as numberOfRows;\n    ")];
                    case 2:
                        numberOfRows = _a.sent();
                        return [2 /*return*/, { numberOfRows: numberOfRows[0][0].numberOfRows, playlists: result[0] }];
                }
            });
        });
    };
    PlaylistDatabase.prototype.getFollowerAndOwnerCollaborativePlaylistById = function (idPremiumListener, playlistId) {
        return __awaiter(this, void 0, void 0, function () {
            var result;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, _super.prototype.getConnection.call(this).raw("\n      SELECT * FROM " + PlaylistDatabase.TABLE_COLLABORATIVE_PLAYLISTS + "\n      WHERE  playlist_owner_id = \"" + idPremiumListener + "\" AND playlist_id = \"" + playlistId + "\" OR followers_id = \"" + idPremiumListener + "\" AND playlist_id = \"" + playlistId + "\"\n    ")];
                    case 1:
                        result = _a.sent();
                        return [2 /*return*/, result[0]];
                }
            });
        });
    };
    PlaylistDatabase.prototype.followCollaborativePlaylist = function (playlistId, idPremiumListener) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, _super.prototype.getConnection.call(this).raw("\n      INSERT INTO " + PlaylistDatabase.TABLE_COLLABORATIVE_PLAYLISTS + " (playlist_id, followers_id)\n      VALUES(\"" + playlistId + "\", \"" + idPremiumListener + "\")\n    ")];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    PlaylistDatabase.prototype.deleteMusicFromPlaylist = function (playlistId, musicsId) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, _super.prototype.getConnection.call(this)
                            .del()
                            .where("playlist_id", playlistId)
                            .whereIn("music_id", musicsId)
                            .from(PlaylistDatabase.TABLE_PLAYLIST_MUSIC)];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    PlaylistDatabase.TABLE_PLAYLIST = "spotenu_playlists";
    PlaylistDatabase.TABLE_PLAYLIST_MUSIC = "spotenu_playlists_musics";
    PlaylistDatabase.TABLE_MUSIC = "spotenu_musics";
    PlaylistDatabase.TABLE_COLLABORATIVE_PLAYLISTS = "spotenu_collaborative_playlists";
    return PlaylistDatabase;
}(BaseDatabase_1.BaseDatabase));
exports.PlaylistDatabase = PlaylistDatabase;
