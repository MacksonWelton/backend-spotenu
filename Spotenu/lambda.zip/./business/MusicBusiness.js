"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MusicBusiness = void 0;
var MusicDatabase_1 = require("../data/MusicDatabase");
var GenericError_1 = require("../Erros/GenericError");
var NotFoundError_1 = require("../Erros/NotFoundError");
var User_1 = require("../model/User");
var tokenGenerator_1 = require("../service/tokenGenerator");
var MusicBusiness = /** @class */ (function () {
    function MusicBusiness() {
    }
    MusicBusiness.prototype.addGenre = function (id, name, token) {
        return __awaiter(this, void 0, void 0, function () {
            var genre, userRole;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        genre = new MusicDatabase_1.MusicDatabase().getGenreByName(name);
                        if ([genre].length === 0) {
                            throw new NotFoundError_1.NotFoundError("This genre already exists in the database");
                        }
                        userRole = new tokenGenerator_1.TokenGenerator().verify(token).role;
                        if (userRole !== User_1.UserRole.ADM) {
                            throw new GenericError_1.GenericError("You must be an administrator to access this feature.");
                        }
                        return [4 /*yield*/, new MusicDatabase_1.MusicDatabase().addGenre(id, name)];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    MusicBusiness.prototype.getGenreByName = function (name, token) {
        return __awaiter(this, void 0, void 0, function () {
            var userRole, genre;
            return __generator(this, function (_a) {
                userRole = new tokenGenerator_1.TokenGenerator().verify(token).role;
                if (userRole !== User_1.UserRole.ADM) {
                    throw new GenericError_1.GenericError("You must be an administrator to access this feature.");
                }
                genre = new MusicDatabase_1.MusicDatabase().getGenreByName(name);
                if (genre === undefined) {
                    throw new NotFoundError_1.NotFoundError("This genre already exists in the database");
                }
                return [2 /*return*/, genre];
            });
        });
    };
    MusicBusiness.prototype.createAlbum = function (id, name, genres, token) {
        return __awaiter(this, void 0, void 0, function () {
            var dataUser, genresData, genresId;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, new tokenGenerator_1.TokenGenerator().verify(token)];
                    case 1:
                        dataUser = _a.sent();
                        if (dataUser.role !== User_1.UserRole.BAND) {
                            throw new GenericError_1.GenericError("Only bands can create albums");
                        }
                        return [4 /*yield*/, new MusicDatabase_1.MusicDatabase().getGenreByName(genres)];
                    case 2:
                        genresData = _a.sent();
                        genresId = genresData.map(function (genre) { return genre.id; });
                        return [4 /*yield*/, new MusicDatabase_1.MusicDatabase().createAlbum(id, dataUser.id, name, genresId)];
                    case 3:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    MusicBusiness.prototype.addMusic = function (id, name, album, token) {
        return __awaiter(this, void 0, void 0, function () {
            var dataUser, dataAlbum, music;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, new tokenGenerator_1.TokenGenerator().verify(token)];
                    case 1:
                        dataUser = _a.sent();
                        if (dataUser.role !== User_1.UserRole.BAND) {
                            throw new GenericError_1.GenericError("Only bands can add musics");
                        }
                        return [4 /*yield*/, new MusicDatabase_1.MusicDatabase().getAlbumByName(album)];
                    case 2:
                        dataAlbum = _a.sent();
                        if (dataAlbum.length === 0) {
                            throw new NotFoundError_1.NotFoundError("This album already exists in the database");
                        }
                        return [4 /*yield*/, new MusicDatabase_1.MusicDatabase().getMusicByName(name)];
                    case 3:
                        music = _a.sent();
                        if (music) {
                            if (dataAlbum === music.album) {
                                throw new GenericError_1.GenericError("This music has already been registered");
                            }
                        }
                        return [4 /*yield*/, new MusicDatabase_1.MusicDatabase().addMusic(id, name, dataAlbum.id_album, dataUser.id)];
                    case 4:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    MusicBusiness.prototype.getAllAlbums = function (token) {
        return __awaiter(this, void 0, void 0, function () {
            var dataUser;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, new tokenGenerator_1.TokenGenerator().verify(token)];
                    case 1:
                        dataUser = _a.sent();
                        if (!dataUser) {
                            throw new GenericError_1.GenericError("You must be logged in to access this feature.");
                        }
                        return [4 /*yield*/, new MusicDatabase_1.MusicDatabase().getAllAlbums()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    MusicBusiness.prototype.getAlbumByBand = function (token, idBand) {
        return __awaiter(this, void 0, void 0, function () {
            var dataUser;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, new tokenGenerator_1.TokenGenerator().verify(token)];
                    case 1:
                        dataUser = _a.sent();
                        if (!dataUser) {
                            throw new GenericError_1.GenericError("You must be logged in to access this feature.");
                        }
                        return [4 /*yield*/, new MusicDatabase_1.MusicDatabase().getAlbumByBand(dataUser.id, idBand)];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    MusicBusiness.prototype.getAllGenres = function (token) {
        return __awaiter(this, void 0, void 0, function () {
            var dataUser;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, new tokenGenerator_1.TokenGenerator().verify(token)];
                    case 1:
                        dataUser = _a.sent();
                        if (!dataUser) {
                            throw new GenericError_1.GenericError("You must be logged in to access this feature.");
                        }
                        return [4 /*yield*/, new MusicDatabase_1.MusicDatabase().getAllGenres()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    MusicBusiness.prototype.getMusicsByBand = function (token, idBand) {
        return __awaiter(this, void 0, void 0, function () {
            var dataUser;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, new tokenGenerator_1.TokenGenerator().verify(token)];
                    case 1:
                        dataUser = _a.sent();
                        if (!dataUser) {
                            throw new GenericError_1.GenericError("You must be logged in to access this feature.");
                        }
                        return [4 /*yield*/, new MusicDatabase_1.MusicDatabase().getMusicsByBand(dataUser.id, idBand)];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    MusicBusiness.prototype.getMusicsbyAlbum = function (idAlbum, token) {
        return __awaiter(this, void 0, void 0, function () {
            var dataUser;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, new tokenGenerator_1.TokenGenerator().verify(token)];
                    case 1:
                        dataUser = _a.sent();
                        if (!dataUser) {
                            throw new GenericError_1.GenericError("You must be logged in to access this feature.");
                        }
                        return [4 /*yield*/, new MusicDatabase_1.MusicDatabase().getMusicsbyAlbum(idAlbum)];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    MusicBusiness.prototype.getAllMusics = function (token) {
        return __awaiter(this, void 0, void 0, function () {
            var dataUser;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, new tokenGenerator_1.TokenGenerator().verify(token)];
                    case 1:
                        dataUser = _a.sent();
                        if (!dataUser) {
                            throw new GenericError_1.GenericError("You must be logged in to access this feature.");
                        }
                        return [4 /*yield*/, new MusicDatabase_1.MusicDatabase().getAllMusics()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    MusicBusiness.prototype.deleteAlbum = function (id, token) {
        return __awaiter(this, void 0, void 0, function () {
            var dataUser;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, new tokenGenerator_1.TokenGenerator().verify(token)];
                    case 1:
                        dataUser = _a.sent();
                        if (!dataUser) {
                            throw new GenericError_1.GenericError("You must be logged in to access this feature.");
                        }
                        return [4 /*yield*/, new MusicDatabase_1.MusicDatabase().deleteAlbum(id)];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    MusicBusiness.prototype.deleteMusic = function (id, token) {
        return __awaiter(this, void 0, void 0, function () {
            var dataUser;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, new tokenGenerator_1.TokenGenerator().verify(token)];
                    case 1:
                        dataUser = _a.sent();
                        if (!dataUser) {
                            throw new GenericError_1.GenericError("You must be logged in to access this feature.");
                        }
                        return [4 /*yield*/, new MusicDatabase_1.MusicDatabase().deleteMusic(id)];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    MusicBusiness.prototype.deleteGenre = function (id, token) {
        return __awaiter(this, void 0, void 0, function () {
            var dataUser;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, new tokenGenerator_1.TokenGenerator().verify(token)];
                    case 1:
                        dataUser = _a.sent();
                        if (!dataUser) {
                            throw new GenericError_1.GenericError("You must be logged in to access this feature.");
                        }
                        return [4 /*yield*/, new MusicDatabase_1.MusicDatabase().deleteGenre(id)];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    return MusicBusiness;
}());
exports.MusicBusiness = MusicBusiness;
